<?php  defined('BASEPATH') OR exit('No direct script access allowed'); ?>﻿
<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!--[if IE]>
            <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <![endif]-->
        <title>Projections </title>
        <!-- BOOTSTRAP STYLE SHEET -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" />
        <script src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.min.js"></script>
        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" />
        <!-- GOOGLE FONT FOR BETTER FONT STYLE -->
        <!--<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css' />-->
        <!-- CUSTOM STYLE CSS -->
        <link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet" />
     </head>
