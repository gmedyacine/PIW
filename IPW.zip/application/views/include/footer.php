<!-- REQUIRED SCRIPTS FILES -->
        <!-- REQUIRED BOOTSTRAP SCRIPTS -->
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
        <img  id="loader" src="<?php echo base_url(); ?>assets/img/loader.svg" />
    </body>

</html>
